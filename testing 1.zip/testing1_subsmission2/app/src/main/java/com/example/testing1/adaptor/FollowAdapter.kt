package com.example.testing1.adaptor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.testing1.api.ItemsItem
import com.example.testing1.api.ListFollowersItem
import com.example.testing1.databinding.ItemRowUserBinding

class FollowAdapter(private val listUser:ArrayList<ListFollowersItem>): RecyclerView.Adapter<viewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return viewHolder(binding)
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        with(holder){
            with(listUser[position]){
                binding.tvItemName.text = this.login
                Glide.with(binding.imgItemPhoto)
                    .load(avatarUrl)
                    .into(binding.imgItemPhoto)
            }
        }
    }
    interface OnItemClickCallback{
        fun onItemClicked(data: ItemsItem)
    }

    override fun getItemCount(): Int = listUser.size

}

class viewHolder(val binding:ItemRowUserBinding) : RecyclerView.ViewHolder(binding.root)
