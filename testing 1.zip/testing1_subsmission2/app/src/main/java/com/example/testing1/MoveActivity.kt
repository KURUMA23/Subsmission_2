package com.example.testing1


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.testing1.adaptor.PagersAdaptor
import com.example.testing1.databinding.ActivityMoveBinding
import com.example.testing1.viewmodels.MoveViewModels
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MoveActivity : AppCompatActivity() {
    companion object{
        const val EXTRA_USER = "extra_user"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }
    private lateinit var binding: ActivityMoveBinding
    private lateinit var userData: String
    private lateinit var viewModel: MoveViewModels


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoveBinding.inflate(layoutInflater)

        supportActionBar?.title = "User Detail"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        userData = intent.getStringExtra(EXTRA_USER)!!




        viewModel(userData)
        tablayout(userData)
        setContentView(binding.root)
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun tablayout(username: String){
        val pagersAdaptor = PagersAdaptor(this)
        val viewPager: ViewPager2 = binding.vpThis
        pagersAdaptor.getUsername(username)
        viewPager.adapter = pagersAdaptor
        val tabs: TabLayout = binding.tabFollow
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])

        }.attach()
        supportActionBar?.elevation = 0f

    }

    private fun viewModel(data : String){
        viewModel = ViewModelProvider(this,PabrikFollow(data))
            .get(MoveViewModels::class.java)
        viewModel.gabungan()
        viewModel.detailUsers().observe(this){
            binding.useRname.text = it.login
            binding.evNama.text = it.name
            binding.perusahaan.text = it.company
            binding.ecLokasi.text = it.location
            binding.vtRepositori.text = it.publicRepos.toString()
            binding.vtFollowing.text = it.following.toString()
            binding.vtFollowers.text = it.followers.toString()
            Glide.with(this@MoveActivity)
                .load(it.avatarUrl)
                .into(binding.evUser)
            Log.v("avatarUrl",it.avatarUrl)

        }
        viewModel.isLoadingDetailUser.observe(this){status ->
            showloading(status)
        }
    }

    private fun showloading(isLoading: Boolean){
        binding.pbDetail.visibility = if (isLoading) View.VISIBLE else View.GONE
    }


}