package com.example.testing1.adaptor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.testing1.api.ItemsItem
import com.example.testing1.api.ListFollowingsItem
import com.example.testing1.databinding.ItemRowUserBinding

class FollowingAdapter(private val listUser:ArrayList<ListFollowingsItem>): RecyclerView.Adapter<viewHolders>() {
    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolders {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return viewHolders(binding)
    }

    override fun onBindViewHolder(holder: viewHolders, position: Int) {
        with(holder){
            with(listUser[position]){
                binding.tvItemName.text = this.login
                Glide.with(binding.imgItemPhoto)
                    .load(avatarUrl)
                    .into(binding.imgItemPhoto)
            }
        }
    }
    interface OnItemClickCallback{
        fun onItemClicked(data: ItemsItem)
    }

    override fun getItemCount(): Int = listUser.size

}

class viewHolders(val binding:ItemRowUserBinding) : RecyclerView.ViewHolder(binding.root)
