package com.example.testing1

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.testing1.viewmodels.MoveViewModels

class PabrikFollow(var data: String):ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MoveViewModels(data) as T
    }
}