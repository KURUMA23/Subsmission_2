package com.example.testing1.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.testing1.Config.ApiConfig
import com.example.testing1.api.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MoveViewModels(var data: String) : ViewModel() {
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoadingDetailUser: LiveData<Boolean> = _isLoading

    private val _isLoadingFollowers = MutableLiveData<Boolean>()
    val isLoadingFollowers: LiveData<Boolean> = _isLoadingFollowers

    private val _isLoadingFollowing = MutableLiveData<Boolean>()
    val isLoadingFollowings: LiveData<Boolean> = _isLoadingFollowing

    private val _listFollowers = MutableLiveData<List<ListFollowersItem>>()
    fun listFollowers():LiveData<List<ListFollowersItem>> {
        return _listFollowers
    }

    private val _detailUser = MutableLiveData<DetailUser>()
    fun detailUsers():LiveData<DetailUser>{
        return _detailUser
    }

    private val _listFollowings = MutableLiveData<List<ListFollowingsItem>>()
    fun listFollowings(): LiveData<List<ListFollowingsItem>>{
        return _listFollowings
    }

    fun gabungan(){
        followers(data)
        following(data)
        username(data)
    }


    fun followers(username: String) {
        _isLoadingFollowers.value = true
        val client = ApiConfig.getApiService().getFollowers(username)
        client.enqueue (object : Callback<ArrayList<ListFollowersItem>> {
            override fun onResponse(call: Call<ArrayList<ListFollowersItem>>, response: Response<ArrayList<ListFollowersItem>>) {
                _isLoadingFollowers.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    _listFollowers.value = responseBody!!
                } else {
                    Log.e("test", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<ArrayList<ListFollowersItem>>, t: Throwable) {
                _isLoadingFollowers.value = false
                Log.e("test", "onFailure: ${t.message.toString()}")
            }
        })
    }
    fun following(username: String) {
        _isLoadingFollowing.value = true
        val client = ApiConfig.getApiService().getFollowing(username)
        client.enqueue (object : Callback<ArrayList<ListFollowingsItem>> {
            override fun onResponse(call: Call<ArrayList<ListFollowingsItem>>, response: Response<ArrayList<ListFollowingsItem>>) {
                _isLoadingFollowing.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    _listFollowings.value = responseBody!!
                } else {
                    Log.e("test", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<ArrayList<ListFollowingsItem>>, t: Throwable) {
                _isLoadingFollowing.value = false
                Log.e("test", "onFailure: ${t.message.toString()}")
            }
        })
    }

    fun username(name: String){
        _isLoading.value = true
        val client = ApiConfig.getApiService().getUser(name)
        client.enqueue (object : Callback<DetailUser> {
            override fun onResponse(call: Call<DetailUser>, response: Response<DetailUser>) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _detailUser.value = response.body()!!
                } else {
                    Log.e("test", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<DetailUser>, t: Throwable) {
                _isLoading.value = false
                Log.e("test", "onFailure: ${t.message.toString()}")
            }
        })
    }
}