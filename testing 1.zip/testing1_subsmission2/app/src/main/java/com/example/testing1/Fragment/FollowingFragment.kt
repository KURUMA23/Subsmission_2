package com.example.testing1.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.testing1.adaptor.FollowingAdapter
import com.example.testing1.api.ListFollowingsItem
import com.example.testing1.databinding.FragmentFollowingBinding
import com.example.testing1.viewmodels.MoveViewModels


class FollowingFragment : Fragment() {
    private lateinit var adapter: FollowingAdapter
    private lateinit var viewModel: MoveViewModels
    private lateinit var recyclerView: RecyclerView
    private var _binding: FragmentFollowingBinding? = null
    private val binding get() =_binding!!
    private val listing = ArrayList<ListFollowingsItem>()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFollowingBinding.inflate(inflater,container,false)


        viewModel = ViewModelProvider(requireActivity()).get(MoveViewModels::class.java)
        viewModel.isLoadingFollowings.observe(viewLifecycleOwner){status ->
            showloadingfollowing(status)
        }
        viewModel.listFollowings().observe(viewLifecycleOwner){
            listing.addAll(it)
            recyclerView = binding.rvFollowing
            recyclerView.layoutManager = LinearLayoutManager(context)
            adapter = FollowingAdapter(listing)
            recyclerView.adapter = adapter
        }
        return binding.root
    }
    private fun showloadingfollowing(isLoading: Boolean){
        binding.PBFollowing.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}