package com.example.testing1

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.testing1.api.ItemsItem
import com.example.testing1.databinding.ActivityMainBinding
import com.example.testing1.viewmodels.MainViewModel


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var rvUser: RecyclerView
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ListUserAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uI()
        viewModels()

        viewModel.isLoading.observe(this) { status ->
            showLoading(status)
        }

        searchuser("budi")

        viewModel.listUser.observe(this) { listuser ->
            updateRecyclelist(listuser)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String): Boolean {
                searchuser(query)
                return true
            }


            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }

    private fun uI(){
        supportActionBar?.title = "Github Users"

        rvUser = binding.rvUser
        rvUser.setHasFixedSize(true)

        showRecyclerList()
    }

    private fun viewModels(){
        viewModel = ViewModelProvider(this)
            .get(MainViewModel::class.java)
    }

    private fun searchuser(username: String){
        viewModel.username(username)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu1 -> {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, MenuFragment())
                    .addToBackStack(null)
                    .commit()
                return true
            }
            R.id.menu2 -> {
                val i = Intent(this, MenuActivity::class.java)
                startActivity(i)
                return true
            }
            else -> return true
        }

    }

    private fun showSelectedHero(user: ItemsItem){
        val moveIntent = Intent(this@MainActivity,MoveActivity::class.java)
        moveIntent.putExtra(MoveActivity.EXTRA_USER, user.login)
        startActivity(moveIntent)
    }

    private fun showRecyclerList(){
        rvUser.layoutManager = LinearLayoutManager (this)
        adapter = ListUserAdapter(arrayListOf())
        rvUser.adapter = adapter

        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback{
            override fun onItemClicked(data: ItemsItem) {
                showSelectedHero(data)
            }
        })
    }
    private fun updateRecyclelist (data: List<ItemsItem>){
        adapter = ListUserAdapter(data)
        rvUser.adapter = adapter

        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback{
            override fun onItemClicked(data: ItemsItem) {
                showSelectedHero(data)
            }
        })
    }
    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}